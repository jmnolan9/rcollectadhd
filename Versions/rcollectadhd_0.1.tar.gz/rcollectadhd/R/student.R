#' Multifaceted Computer Science Students Data To Identify
#' Depression Level
#'
#' @description
#' This dataset comprises survey results from 100 computer science
#' students, aiming to identify correlations between their
#' depression levels, class performance, and ADHD patterns through
#' data analysis. This dataset is designed to facilitate a
#' comprehensive analysis of the interplay between demographic
#' factors, academic performance, mental health, study habits, and
#' social dynamics among individuals in the specified context. This
#' dataset was taken from Kaggle.
#'
#' @format a data frame with 10 columns
#'
#'  \describe{
#'    \item{\code{Age}}{Represents the age of the individuals in the dataset,
#'    providing insight into the age distribution of the study.}
#'    \item{\code{Gender}}{Indicates the gender of each individual, allowing for
#'    the exploration of gender-related patterns and trends within the dataset.}
#'    \item{\code{AcademicPerformance}}{Reflects the academic achievements of
#'    individuals.}
#'    \item{\code{TakingNoteInClass}}{Describes about individuals take notes
#'    during class, providing insights into study habits and engagement during
#'    lectures.}
#'    \item{\code{DepressionStatus}}{Indicates the presence or absence of
#'    depressive symptoms, contributing valuable information about the mental
#'    health of individuals in the dataset.}
#'    \item{\code{FaceChallengesToCompleteAcademicTask}}{Explores whether
#'    individuals encounter challenges in completing academic tasks.}
#'    \item{\code{LikePresentation}}{Reflects individuals' preferences for
#'    presentations, offering insights into their learning style and engagement
#'    with visual or oral communication. This aim also measure is they extrovert
#'     or introvert.}
#'    \item{\code{SleepPerDayHours}}{Represents the average hours of sleep
#'    individuals get per day, providing information on sleep patterns and
#'    potential correlations with academic performance.}
#'    \item{\code{NumberOfFriend}}{Quantifies the social aspect by indicating the
#'     number of friends each individual has, contributing to the understanding
#'     of social dynamics within the dataset.}
#'    \item{\code{LikeNewThings}}{Explores individuals' receptiveness to new
#'    experiences or concepts, offering insights into their adaptability and
#'    openness to innovation.}
#'   }
#'
#' @source "Psychosocial Dimensions of Student Life" authored by
#' Md. Ismiel Hossen Abir on Kaggle:
#' https://www.kaggle.com/datasets/mdismielhossenabir/psychosocial-dimensions-of-student-life
#'
'student'
