#' Sub-clinical ADHD behaviors and classroom functioning in
#' schoolage children
#'
#' @description
#' Observations on children aged 9-11 in classroom settings, for a
#' study on the effects of sub-clinical hyperactive and inattentive
#' behaviors on social and academic functioning.
#'
#' @format A data frame with 686 observations on the following 4 variables
#'
#' \describe{
#'   \item{sex}{1=boy; 2=girl}
#'   \item{ethn}{1=boy; 2=girl}
#'   \item{hypb}{1=boy; 2=girl}
#'   \item{fcn}{1=boy; 2=girl}
#'  }
#'
#' @references Brewis, A.A. Schmidt, K.L., and Meyer, M.C. (2000)
#' ADHD-type behavior and harmful dysfunction in childhood: a
#' cross-cultural model, American Anthropologist, 102(4), pp823-828
#'
#' @source '{DoubleCone}' package
#'
'doublecone'
